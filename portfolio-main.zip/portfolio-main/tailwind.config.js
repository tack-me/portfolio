// tailwind.config.js
tailwind.config = {
    theme: {
        extend: {
            fontFamily: {
                header: ["Font Name", "sans-serif"],
            },
        },
    },
};
